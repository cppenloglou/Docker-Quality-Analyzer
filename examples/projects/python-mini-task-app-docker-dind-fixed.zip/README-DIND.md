# Docker-in-Docker note

The default `docker-compose.yml` is DIND-safe and does not bind-mount the project folder.

Why: inside Docker-in-Docker, a mount such as `.:/usr/src/app` is resolved by the inner Docker daemon, not by your host filesystem. If that path is empty or different inside the DIND container, it overwrites `/usr/src/app` and hides the copied `app/` package. Then Python fails with:

```text
/usr/local/bin/python: Error while finding module specification for 'app.main' (ModuleNotFoundError: No module named 'app')
```

Run inside DIND:

```bash
docker compose up --build
```

Run locally with live reload / source mount:

```bash
docker compose -f docker-compose.yml -f docker-compose.local.yml up --build
```
