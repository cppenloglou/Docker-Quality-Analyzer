package com.example.demo;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class TestController {

    @GetMapping
    public List<String> getItems(){
        return List.of("Renault", "Toyota", "Volvo", "Ford", "Chevrolet", "BMW");
    }
}