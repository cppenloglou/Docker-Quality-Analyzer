# Python Mini Task App

A small working Flask web application with:

- A browser UI for adding, completing, and deleting tasks
- JSON API endpoints
- A health endpoint
- Docker and Docker Compose support
- Basic tests

## Project structure

```text
.
├── app/
│   ├── __init__.py
│   ├── main.py
│   ├── static/
│   │   └── style.css
│   └── templates/
│       └── index.html
├── tests/
│   └── test_app.py
├── Dockerfile
├── docker-compose.yml
├── requirements.txt
└── README.md
```

## Run locally

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python -m app.main
```

Open:

```text
http://localhost:5000
```

## Run with Docker Compose

```bash
docker compose up --build
```

Open:

```text
http://localhost:5000
```

## API

### Health check

```bash
curl http://localhost:5000/health
```

### List tasks

```bash
curl http://localhost:5000/api/tasks
```

### Create task

```bash
curl -X POST http://localhost:5000/api/tasks \
  -H 'Content-Type: application/json' \
  -d '{"title":"Learn Flask"}'
```

## Tests

```bash
pytest
```
