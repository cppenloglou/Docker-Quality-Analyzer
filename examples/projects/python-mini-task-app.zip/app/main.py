from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from itertools import count
from typing import Any

from flask import Flask, jsonify, redirect, render_template, request, url_for

app = Flask(__name__)


@dataclass
class Task:
    id: int
    title: str
    done: bool = False
    created_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "title": self.title,
            "done": self.done,
            "created_at": self.created_at.isoformat(),
        }


_next_id = count(1)
_tasks: list[Task] = [
    Task(id=next(_next_id), title="Run the app with Docker Compose"),
    Task(id=next(_next_id), title="Add your first custom task"),
]


def find_task(task_id: int) -> Task | None:
    return next((task for task in _tasks if task.id == task_id), None)


@app.get("/")
def index():
    remaining = sum(not task.done for task in _tasks)
    return render_template("index.html", tasks=_tasks, remaining=remaining)


@app.post("/tasks")
def create_task():
    title = request.form.get("title", "").strip()
    if title:
        _tasks.append(Task(id=next(_next_id), title=title))
    return redirect(url_for("index"))


@app.post("/tasks/<int:task_id>/toggle")
def toggle_task(task_id: int):
    task = find_task(task_id)
    if task is not None:
        task.done = not task.done
    return redirect(url_for("index"))


@app.post("/tasks/<int:task_id>/delete")
def delete_task(task_id: int):
    global _tasks
    _tasks = [task for task in _tasks if task.id != task_id]
    return redirect(url_for("index"))


@app.get("/api/tasks")
def api_list_tasks():
    return jsonify([task.to_dict() for task in _tasks])


@app.post("/api/tasks")
def api_create_task():
    data = request.get_json(silent=True) or {}
    title = str(data.get("title", "")).strip()
    if not title:
        return jsonify({"error": "title is required"}), 400

    task = Task(id=next(_next_id), title=title)
    _tasks.append(task)
    return jsonify(task.to_dict()), 201


@app.get("/health")
def health():
    return jsonify({"status": "ok", "tasks": len(_tasks)})


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
